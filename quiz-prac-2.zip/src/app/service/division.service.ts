import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UiService } from './ui.service'; // Assuming you have a UI service for error messages

interface Division {
  id: string;
  title: string;
  description: string;
  dueDate: Date; 
  status: 'completed' | 'not completed'; 
}

@Injectable({ providedIn: 'root' })
export class DivisionService {
  private divisionsSubject = new BehaviorSubject<Division[]>([]);
  public divisions$: Observable<Division[]> = this.divisionsSubject.asObservable();

  constructor(private uiService: UiService) { // Inject UiService for error handling
    this.loadDivisionsFromLocalStorage();
  }

  private loadDivisionsFromLocalStorage() {
    const storedDivisions = localStorage.getItem('divisions');
    if (storedDivisions) {
      this.divisionsSubject.next(JSON.parse(storedDivisions));
    }
  }

  private saveDivisionsToLocalStorage() {
    localStorage.setItem('divisions', JSON.stringify(this.divisionsSubject.value));
  }

  addDivision(division: Omit<Division, 'id'>) { // Don't expect id from input
    const newDivision: Division = { id: Date.now().toString(), ...division }; 
    const updatedDivisions = [...this.divisionsSubject.value, newDivision];
    this.divisionsSubject.next(updatedDivisions);
    this.saveDivisionsToLocalStorage();
  }

  updateDivision(id:any , division: Division) {
    console.log('division', division);
    
    
    const updatedDivisions = this.divisionsSubject.value.map(d => 
      d.id === id ? division : d
    );
    this.divisionsSubject.next(updatedDivisions);
    this.saveDivisionsToLocalStorage();
  }

  deleteDivision(id: string) {
    const updatedDivisions = this.divisionsSubject.value.filter(d => d.id !== id);
    this.divisionsSubject.next(updatedDivisions);
    this.saveDivisionsToLocalStorage();
  }
}
