import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermissionLooderComponent } from './permission-looder.component';



@NgModule({
  declarations: [
    PermissionLooderComponent
  ],
  imports: [
    CommonModule
  ]
})
export class PermissionLooderModule { }
