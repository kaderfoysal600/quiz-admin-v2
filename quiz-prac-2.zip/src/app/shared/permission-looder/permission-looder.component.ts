import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-permission-looder',
  templateUrl: './permission-looder.component.html',
  styleUrls: ['./permission-looder.component.scss']
})
export class PermissionLooderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
