import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-permission-chield',
  templateUrl: './permission-chield.component.html',
  styleUrls: ['./permission-chield.component.scss']
})
export class PermissionChieldComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
